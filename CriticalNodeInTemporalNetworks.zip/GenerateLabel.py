#coding=utf-8
import random
import numpy as np

class SIR:
    def __init__(self, infected, beta, miu):
        '''
        :param infected: 初始感染节点
        :param beta: 感染概率
        :param miu: 恢复概率
        '''
        self.inf = infected
        self.beta = beta
        self.miu = miu
    def temporal_SIR(self, temporalG):
        N = 1000
        re = 0
        while N > 0:
            inf = set(self.inf)
            R = set()
            for G in temporalG:
                newInf = []
                for i in inf:
                    for j in G.neighbors(i):
                        k = random.uniform(0,1)
                        if k < self.beta and j not in inf and j not in R:
                            newInf.append(j)
                    k2 = random.uniform(0, 1)
                    if k2 >self.miu:
                        newInf.append(i)
                    else:
                        R.add(i)
                inf = set(newInf)
            re += len(R)+len(inf)
            N -= 1
        return re/1000.0

    def temporal_SIR_weighted(self, temporalG):
        N = 1000
        re = 0
        while N > 0:
            inf = set(self.inf)
            R = set()
            for G in temporalG:
                newInf = []
                for i in inf:
                    for j in G.neighbors(i):
                        weight = G[i][j]['weight']
                        k = random.uniform(0, 1)
                        if k < 1-(1-self.beta)**weight and j not in inf and j not in R:
                            newInf.append(j)
                    k2 = random.uniform(0, 1)
                    if k2 >self.miu:
                        newInf.append(i)
                    else:
                        R.add(i)
                inf = set(newInf)
            re += len(R)+len(inf)
            N -= 1
        return re/1000.0

    def static_SIR(self, G):
        N = 1000
        re = 0
        while N > 0:
            inf = set(self.inf)
            R = set()
            while len(inf) != 0:
                newInf = []
                for i in inf:
                    for j in G.neighbors(i):
                        k = random.uniform(0, 1)
                        if k < self.beta and j not in inf and j not in R:
                            newInf.append(j)
                    k2 = random.uniform(0, 1)
                    if k2 > self.miu:
                        newInf.append(i)
                    else:
                        R.add(i)
                inf = set(newInf)
            re += len(R) + len(inf)
            N -= 1
        return re / 1000.0

class Label:
    def __init__(self):
        ...

    def temporal_label(self, temporalG, beta, tempT, T):
        '''
        标注temporalG 在tempT时刻的节点影响力，即tempT+1到tempT+T+1时间内的影响规模
        :param temporalG:
        :param T:
        :param k:
        :return:np.array格式的label
        '''
        nodes = sorted(temporalG[0].nodes())
        label = []
        for node in nodes:
            S = SIR([node], beta, 0.1)
            label.append([S.temporal_SIR(temporalG[tempT + 1:tempT + T + 1])])
        np.save('Label/' + temporalG[0].name + '_' + str(tempT)+'_' + str(beta)+ '.npy', np.array(label))
        return label

    def temporal_label_weighted(self, temporalG, beta, tempT, T):
        '''
        标注temporalG 在tempT时刻的节点影响力，即tempT+1到tempT+T+1时间内的影响规模
        :param temporalG:
        :param T:
        :param k:
        :return:np.array格式的label
        '''
        nodes = sorted(temporalG[0].nodes())
        label = []
        for node in nodes:
            S = SIR([node], beta, 0.1)
            label.append([S.temporal_SIR_weighted(temporalG[tempT + 1:tempT + T + 1])])
        np.save('Weighted/Label/' + temporalG[0].name + '_' + str(tempT)+'_' + str(beta)+ '.npy', np.array(label))
        return label