#coding=utf-8

import networkx as nx
import numpy as np
import DL_model as DL

class Feature:
    def __init__(self):
        ...

    def static_neighbor_feature(self, G, k):
        '''
        对单个snapshot生成K维的特征
        :param G:network
        :param k:维度
        :return: data np.array
        '''
        NM = {}
        data = []
        nodes = sorted(G.nodes())
        for node in nodes:
            neighbors = [node]
            seeds = [node]
            while len(neighbors) < k:
                new_seeds = set([])
                rank = set([])
                for seed in seeds:
                    for neighbor in G.neighbors(seed):
                        if neighbor not in neighbors:
                            rank.add((neighbor, G.out_degree(neighbor)))
                            new_seeds.add(neighbor)
                rank = sorted(rank, key=lambda x: x[1], reverse=True)
                for neighbor in rank:
                    neighbors.append(neighbor[0])
                    if len(neighbors) == k:
                        NM[node] = neighbors
                        break
                seeds = new_seeds
                if len(seeds) == 0:
                    NM[node] = neighbors
                    break

        for node in nodes:
            subM = nx.adjacency_matrix(G, NM[node]).todense()
            for i in range(len(subM)):
                subM[i, i] = G.out_degree(NM[node][i])
                if i == 0:
                    for j in range(1, len(subM)):
                        if subM[i, j] == 1:
                            subM[i, j] = G.out_degree(NM[node][j])
                            subM[j, i] = subM[i, j]
            returnVect = []
            for i in range(k):
                for j in range(k):
                    if i >= len(subM) or j >= len(subM):
                        returnVect.append(0)
                    else:
                        returnVect.append(subM[i, j])
            returnVect = np.array(returnVect)
            Re = returnVect.reshape(1, k, k)
            data.append(Re)
        return data
    def static_neighbor_feature_weighted(self, G, k):
        '''
        对单个snapshot生成K维的特征
        :param G:network
        :param k:维度
        :return: data np.array
        '''
        NM = {}
        data = []
        nodes = sorted(G.nodes())
        for node in nodes:
            neighbors = [node]
            seeds = [node]
            while len(neighbors) < k:
                new_seeds = set([])
                rank = set([])
                for seed in seeds:
                    for neighbor in G.neighbors(seed):
                        if neighbor not in neighbors:
                            rank.add((neighbor, G.out_degree(neighbor)))
                            new_seeds.add(neighbor)
                rank = sorted(rank, key=lambda x: x[1], reverse=True)
                for neighbor in rank:
                    neighbors.append(neighbor[0])
                    if len(neighbors) == k:
                        NM[node] = neighbors
                        break
                seeds = new_seeds
                if len(seeds) == 0:
                    NM[node] = neighbors
                    break

        for node in nodes:
            subM = nx.adjacency_matrix(G, NM[node]).todense()
            for i in range(len(subM)):
                for j in range(len(subM)):
                    if i==j:
                        subM[i, j] = G.out_degree(NM[node][i])
                    else:
                        if G.has_edge(NM[node][i],NM[node][j]):
                            subM[i, j] = G[NM[node][i]][NM[node][j]]['weight']
            returnVect = []
            for i in range(k):
                for j in range(k):
                    if i >= len(subM) or j >= len(subM):
                        returnVect.append(0)
                    else:
                        returnVect.append(subM[i, j])
            returnVect = np.array(returnVect)
            Re = returnVect.reshape(1, k, k)
            data.append(Re)
        return data

    def temporal_feature(self, temporalG, k, tempT, T):
        tempM = []
        nodes = sorted(temporalG[0].nodes())
        for G in temporalG[tempT-T+1:tempT+1]:
            tempM.append(self.static_neighbor_feature(G, k))
        feature_GCN = []
        for i in nodes:
            feature_GCN.append([])
        for i in range(len(tempM)):
            for j in range(len(tempM[i])):
                feature_GCN[j].append(tempM[i][j])
        feature_GCN = np.array(feature_GCN)
        # predict = DL.Predict()
        # feature_LSTM = []
        # for i in range(len(feature_GCN)):
        #     feature_LSTM.append(predict.predict_CNN(feature_GCN[i], 'BA1000_2_28_1.5'))
        # np.save('Feature/' + temporalG[0].name + '.npy', np.array(feature_LSTM))
        np.save('Feature/' + temporalG[0].name +'_' +str(tempT)+'_' +str(T)+ '.npy', feature_GCN)
        return feature_GCN

    def temporal_feature_weighted(self, temporalG, k, tempT, T):
        tempM = []
        nodes = sorted(temporalG[0].nodes())
        for G in temporalG[tempT-T+1:tempT+1]:
            tempM.append(self.static_neighbor_feature_weighted(G, k))
        feature_GCN = []
        for i in nodes:
            feature_GCN.append([])
        for i in range(len(tempM)):
            for j in range(len(tempM[i])):
                feature_GCN[j].append(tempM[i][j])
        feature_GCN = np.array(feature_GCN)
        # predict = DL.Predict()
        # feature_LSTM = []
        # for i in range(len(feature_GCN)):
        #     feature_LSTM.append(predict.predict_CNN(feature_GCN[i], 'BA1000_2_28_1.5'))
        # np.save('Feature/' + temporalG[0].name + '.npy', np.array(feature_LSTM))
        np.save('Weighted/Feature/' + temporalG[0].name +'_' +str(tempT)+'_' +str(T)+ '.npy', feature_GCN)
        return feature_GCN
