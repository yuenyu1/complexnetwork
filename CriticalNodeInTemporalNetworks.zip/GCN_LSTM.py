#coding=utf-8
import GenerateNetworks as GN
import DL_model as DL
import GenerateFeature as GF
import numpy as np
import GenerateLabel as GL
from torch.utils.data import DataLoader
import Experiment

def feature(network, t):
    gf_feature = GF.Feature()
    gn_networks = GN.Networks()
    TG = gn_networks.RealNetwork(network[0])
    gf_feature.temporal_feature(TG, 28, network[2], t)

def label(network):
    # X = [x / 100 for x in range(1, 11)]
    X = [0.05]
    gl_label = GL.Label()
    gn_networks = GN.Networks()
    TG = gn_networks.RealNetwork(network[0])
    for x in X:
        print(x)
        gl_label.temporal_label(TG, x, network[2], 10)

def grenerateTrainSet(network, t):
    dl_train = DL.Train()
    dl_train.train_CNN_LSTM2(network[0][0], network[2], 0.05, t)

def feature_weighted(networks):
    gf_feature = GF.Feature()
    gn_networks = GN.Networks()
    train_S = [1, 2, 4, 6, 8, 10, 15, 20, 25, 30]
    for network in networks:
        print(network[0])
        TG_weighted = gn_networks.RealNetwork_weighted(network[0])
        for t in train_S:
            print(t)
            gf_feature.temporal_feature_weighted(TG_weighted, 28, network[1], t)
            gf_feature.temporal_feature_weighted(TG_weighted, 28, network[2], t)

def label_weighted(networks):
    X = [x / 100 for x in range(1, 11)]
    # X = [0.05]
    gl_label = GL.Label()
    gn_networks = GN.Networks()
    for network in networks:
        print(network[0])
        TG_weighted = gn_networks.RealNetwork_weighted(network[0])
        for x in X:
            print(x)
            gl_label.temporal_label_weighted(TG_weighted, x, network[1], 10)
            # gl_label.temporal_label_weighted(TG_weighted, x, network[2], 10)

def grenerateTrainSet_weighted(networks):
    dl_train = DL.Train()
    # X = [x / 100 for x in range(1, 11)]
    X = [0.05]
    train_S = [1, 2, 4, 6, 8, 10, 15, 20, 25, 30]
    for network in networks:
        print(network[0])
        for x in X:
            print(x)
            for t in train_S:
                dl_train.train_CNN_LSTM_weighted(network[0][0], network[2], x, t)

def grenerateTrainSet_weighted2(networks):
    dl_train = DL.Train()
    # X = [x / 100 for x in range(1, 11)]
    X = [0.05]
    train_S = [1, 2, 4, 6, 8, 10, 15, 20, 25, 30]
    for network in networks:
        print(network[0])
        for x in X:
            print(x)
            for t in train_S:
                dl_train.train_CNN_LSTM2_weighted(network[0][0], network[2], x, t)

def grenerateTrainSet_embedding(networks, methods):
    dl_train = DL.Train()
    for network in networks:
        print(network[0])
        for method in methods:
            dl_train.train_LSTM(network[0][0], network[2], 0.05, network[3], method)

if __name__ == '__main__':
    # idx1:当前时刻, idx2:训练时刻
    # networks = [[['Email', 7, 0, 75, 1], 40, 30]]
    # networks = [[['Contact',1/24, 0, 69, 0], 40, 30]]
    # networks = [[['infectious', 1 / 24/12, 1, 79, 0], 40, 30]]
    # networks = [[['DNC', 1 / 2, 937, 1000, 1], 40, 30]]
    # networks = [[['UCI', 1, 0, 58, 1], 40, 30]]
    # networks = [[['Email', 7, 0, 75, 1], 40, 30], [['Contact',1/24, 0, 69, 0], 40, 30],
    #             [['DNC', 1 / 2, 0, 56, 1], 40, 30], [['UCI', 1, 0, 58, 1], 40, 30]]

    # grenerateTrainSet([['Contact',1/24, 0, 69, 0], 40, 30], 6)
    # la = np.load('Feature/Email_30_6.npy')
    # print(la.shape)
    # import torch
    # la = torch.from_numpy(la).float()
    # lb1 = la[:, 1]
    # lb2 = la[:, 2]
    # lb3 = torch.cat([lb1,lb2],dim=1)
    # print(lb3.shape)

    # train_time = []
    # train_S = [1, 2, 4, 8, 15, 30]
    # for network in networks:
    #     label(network)
    #     tempT = []
    #     for t in train_S:
    #         import time
    #         tt = time.time()
    #         feature(network, t)
    #         grenerateTrainSet(network, t)
    #         tempT.append(time.time()-tt)
    #     train_time.append(tempT)
    # print(train_time)

    # ex = Experiment.Experiments()
    # ex.compare_S_topK(networks, 100)
    # ex.compare_S_corr(networks)
    # ex.compare_topK(100)
    # ex.compare_corr()


#Weighted
    # 【名称，间隔(days)，left，right，is_directed,threshold】, 预测时刻，训练时刻, train_s
    networks = [[['Email', 7, 0, 75, 1, 100], 40, 30, 10], [['Contact',1/24, 0, 69, 0, 20], 40, 30, 8],
                [['DNC', 1 / 2, 0, 56, 1, 100], 40, 30, 15], [['UCI', 1, 0, 58, 1, 200], 40, 30, 2]]
    # networks = [[['Contact',1/24, 0, 69, 0, 20], 40, 30, 8]]
    # networks = [[['DNC', 1 / 2, 0, 56, 1, 100], 40, 30, 15]]
    # networks = [[['UCI', 1, 0, 58, 1, 200], 40, 30, 2]]
    # networks = [[['infectious', 1/24/12, 1, 79, 0, 20], 40, 30]]
    # networks = [[['Fri', 1/24, 0, 80, 0, 20], 40, 30]]
    # networks = [[['Email', 7, 0, 75, 1, 100], 40, 30, 10]]
    methods = ['node2vec','struc2vec']

    # la = np.load('Label/bitcoinalpha_40_0.05.npy')
    # la.sort(axis=0)
    # print(la)

    # feature_weighted(networks)
    # label_weighted(networks)
    # grenerateTrainSet_weighted(networks)
    # grenerateTrainSet_embedding(networks, methods)
    # grenerateTrainSet_weighted2(networks)

    ex = Experiment.Experiments()
    # ex.compare_S_topK_weighted(networks, 10)
    # ex.compare_S_corr_weighted(networks)
    # ex.compare_topK_weighted(networks, 0.05)
    ex.compare_corr_weighted(networks)
    # ex.compare_time(networks)



























    #生成网络
    gn_networks = GN.Networks()
    # TG = gn_networks.TSFNetworks('Train', 1000, 2, 0.02, 'BAtrain')
    # TG = gn_networks.RealNetwork(network)
    # nodes = sorted(TG[0].nodes())

    #生成feature
    gf_feature = GF.Feature()
    # feature = gf_feature.temporal_feature(TG[40:50], 28)
    # print(feature.shape)

    # train_feature = []
    # for tempT in [10, 20, 30]:
    #     train_feature += gf_feature.temporal_feature(TG[tempT-10:tempT], 28)
    # np.save('Feature/' + 'Train' + '.npy', np.array(train_feature))

    #生成label
    gl_label = GL.Label()
    # gl_label.temporal_label(TG, 0.05, 49, 10)
    # train_label = []
    # for tempT in [10, 20, 30]:
    #     train_label += gl_label.temporal_label(TG, 0.05, tempT-1, 10)
    # np.save('Label/' + 'Train' + '_' + str(0.05) + '.npy', np.array(train_label))
    #训练
    dl_train =DL.Train()
    # dl_train.train_CNN_LSTM('Train_1000_2_0.02', 0.05)
    #预测
    dl_predict = DL.Predict()
    # rank = dl_predict.predict_CNN_LSTM(nodes, np.load('Feature/Train_1000_2_0.02.npy'),'Train_1000_2_0.02_0.05')
    # print(rank)

