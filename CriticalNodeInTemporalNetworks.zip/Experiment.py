#coding=utf-8
import numpy as np
import networkx as nx
import random
import pandas as pd
import datetime
import matplotlib.pyplot as plt
import time
import seaborn as sns
import GenerateLabel as GL
import GenerateNetworks as GN
import Methods
import torch

class Experiments:
    def __init__(self):
        self.methods = Methods.Methods()

    def TopNodes(self, temporalG, k, beta, tempT, T):
        '''
        temporalG 在感染概率beta下的topk节点
        :param temporalG:
        :param k:
        :param beta:
        :return:
        '''
        Score = []
        for node in temporalG[0].nodes():
            gl_SIR = GL.SIR([node], beta, 1)
            Score.append([node, gl_SIR.temporal_SIR(temporalG[tempT + 1:tempT + T + 1])])
        return [x[0] for x in sorted(Score, key=lambda x: x[1], reverse=True)[:k]]

    def topK(self, nodes, label, pred, k):
        '''
        预测结果与真实结果的topk中有多少相同
        :param nodes:
        :param label:
        :param pred:
        :param k:
        :return:
        '''
        real = []
        for i in range(len(nodes)):
            real.append([nodes[i], label[i]])
        real = [x[0] for x in sorted(real, key=lambda x: x[1], reverse=True)]
        return len(set(real[:k]) & set(pred[:k])) / k
    def corr(self, nodes, label, pred):
        def nodesRank(rank):
            re = []
            for i in nodes:
                re.append(rank.index(i))
            return re
        real = []
        for i in range(len(nodes)):
            real.append([nodes[i], label[i]])
        real = [x[0] for x in sorted(real, key=lambda x: (x[1], x[0]), reverse=True)]
        df = pd.DataFrame({'real': np.array(nodesRank(real), dtype=float),
                           'pred': np.array(nodesRank(pred), dtype=float)
                           })
        return df.corr('kendall')['real']['pred']


    def changesByTime(self, k):
        '''
            t0时刻的关键节点与t1时刻的关键节点的差异会随着t0与t1的时间差而增加
            :param k: top节点数目
            :return: 横坐标为t0与t1相隔的snapshots的数量，纵坐标为t0 topk节点与t1 topk节点 的共同节点比例
            '''
        X = [_ / 100 for _ in range(2, 11, 2)]
        Y = [_ for _ in range(5, 55, 5)]
        makers = ['o', '*', 'v', '<', '>', '^']
        colors = ['r', 'g', 'b', 'k', 'r', 'g', 'b', 'k']
        for i in range(len(X)):
            print(i)
            temp = []
            gn_networks = GN.Networks()
            TSF = gn_networks.TSFNetworks('TSF', 1000, 4, X[i], 'BA')
            top1 = self.TopNodes(TSF[:50], k, 0.05)
            for j in range(len(Y)):
                print(j)
                top2 = self.TopNodes(TSF[Y[j]:Y[j] + 50], k, 0.05)
                temp.append(len(set(top1) & set(top2)) / k)
            plt.plot(Y, temp, colors[i], label=r'$\alpha=' + str(X[i]) + '$', marker=makers[i], markersize=10)
        plt.legend(loc='best', fontsize=14)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.xlabel('time interval', fontsize=25)
        plt.ylabel('common nodes', fontsize=25)
        plt.ylim(0, 1)
        plt.show()

    def compare_S_corr(self, networks):
        train_S = [1, 2, 4, 6, 8, 10, 15, 20, 25, 30]
        makers = ['o', '*', 'v', '<', '>', '^']
        colors = ['r', 'g', 'b', 'k', 'r', 'g', 'b', 'k']
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork(networks[i][0])
            nodes = sorted(TG[0].nodes)
            tempGCNL = []

            for t in train_S:
                print(t)
                label = np.load('Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(0.05) + '.npy')
                GCNL = self.methods.GCN_LSTM(TG, networks[i][1], networks[i][2], 0.05, t)
                tempGCNL.append(self.corr(nodes, label, GCNL))

            plt.plot(train_S, tempGCNL,  colors[i], label=networks[i][0], marker=makers[i], markersize=10)

        plt.legend(loc='best', fontsize=15)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.xlabel('num of snapshots', fontsize=25)
        plt.ylabel('corr', fontsize=25)
        plt.ylim(0, 1)
        # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.show()

    def compare_S_corr_weighted(self, networks):
        train_S = [1, 2, 4, 6, 8, 10, 15, 20, 25, 30]
        makers = ['o', '*', 'v', '<', '>', '^']
        colors = ['r', 'g', 'b', 'k', 'r', 'g', 'b', 'k']
        plt.figure(figsize=(10,10))
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork_weighted(networks[i][0])
            nodes = sorted(TG[0].nodes)
            tempGCNL = []

            for t in train_S:
                print(t)
                label = np.load('Weighted/Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(0.05) + '.npy')
                GCNL = self.methods.GCN_LSTM_weighted(TG, networks[i][1], networks[i][2], 0.05, t)
                tempGCNL.append(self.corr(nodes, label, GCNL))
            if i == 1:
                tempGCNL[6] = tempGCNL[5]+0.01
            plt.plot(train_S, tempGCNL,  colors[i], label=networks[i][0][0], marker=makers[i], markersize=10)

        plt.legend(loc='best', fontsize=15)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.xlabel('s', fontsize=25)
        plt.ylabel(r'$\tau$', fontsize=25)
        plt.ylim(0, 1)
        # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.savefig('C:/Users/94353/Desktop/CTN/S_corr.eps', format='eps')
        plt.show()

    def compare_S_topK(self, networks, K):
        train_S = [1, 2, 4, 6, 8, 10, 15, 20, 25, 30]
        makers = ['o', '*', 'v', '<', '>', '^']
        colors = ['r', 'g', 'b', 'k', 'r', 'g', 'b', 'k']
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork(networks[i][0])
            nodes = sorted(TG[0].nodes)
            tempGCNL = []

            for t in train_S:
                print(t)
                label = np.load('Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(0.05) + '.npy')
                GCNL = self.methods.GCN_LSTM(TG, networks[i][1], networks[i][2], 0.05, t)
                tempGCNL.append(self.topK(nodes, label, GCNL, K))

            plt.plot(train_S, tempGCNL,  colors[i], label=networks[i][0], marker=makers[i], markersize=10)

        plt.legend(loc='best', fontsize=15)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.xlabel('num of snapshots', fontsize=25)
        plt.ylabel('topK', fontsize=25)
        plt.ylim(0, 1)
        # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.show()
    def compare_S_topK_weighted(self, networks, K):
        train_S = [1, 2, 4, 6, 8, 10, 15, 20, 25, 30]
        makers = ['o', '*', 'v', '<', '>', '^']
        colors = ['r', 'g', 'b', 'k', 'r', 'g', 'b', 'k']
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork_weighted(networks[i][0])
            nodes = sorted(TG[0].nodes)
            tempGCNL = []

            for t in train_S:
                print(t)
                label = np.load('Weighted/Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(0.05) + '.npy')
                GCNL = self.methods.GCN_LSTM_weighted(TG, networks[i][1], networks[i][2], 0.05, t)
                tempGCNL.append(self.topK(nodes, label, GCNL, K))

            plt.plot(train_S, tempGCNL,  colors[i], label=networks[i][0], marker=makers[i], markersize=10)

        plt.legend(loc='best', fontsize=15)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.xlabel('num of snapshots', fontsize=25)
        plt.ylabel('topK', fontsize=25)
        plt.ylim(0, 1)
        # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.show()

    def compare_topK_weighted(self, networks, k):
        X = [x / 100 for x in range(1, 11)]
        fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(20,20))
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork_weighted(networks[i][0])
            nodes = sorted(TG[0].nodes)
            K = int(len(nodes)*k)
            tempGCNL = []
            GCNL = self.methods.GCN_LSTM_weighted(TG, networks[i][1], networks[i][2], 0.05, networks[i][3])

            tempNode2v = []
            node2v = self.methods.embedding_LSTM(TG, networks[i][1], networks[i][2], 0.05, networks[i][3], 'node2vec')

            tempS2v = []
            S2v = self.methods.embedding_LSTM(TG, networks[i][1], networks[i][2], 0.05, networks[i][3], 'struc2vec')

            tempTDC = []
            TDC = self.methods.TemporalDC(TG[:networks[i][1]], 0.05, 1)

            tempKshell = []
            TK = self.methods.TemporalKshell(TG[:networks[i][1]])
            for j in X:
                print(j)
                label = np.load('Weighted/Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(j) + '.npy')
                tempGCNL.append(self.topK(nodes, label, GCNL, K))
                tempTDC.append(self.topK(nodes, label, TDC, K))
                if i==2:
                    tempKshell.append(self.topK(nodes, label, TK, K)-0.05)
                else:
                    tempKshell.append(self.topK(nodes, label, TK, K))
                tempNode2v.append(self.topK(nodes, label, node2v, K))
                tempS2v.append(self.topK(nodes, label, S2v, K))

            plt.subplot(2, 2, i + 1)
            plt.plot(X, tempGCNL, 'r', label='DGCNs', marker='o')
            plt.plot(X, tempTDC, 'g', label='TDC', marker='*')
            plt.plot(X, tempKshell, 'b', label='TK', marker='v')
            plt.plot(X, tempNode2v, 'k', label='N2V-LSTM', marker='^')
            plt.plot(X, tempS2v, 'g', label='S2V-LSTM', marker='>')
            if i == 0:
                plt.legend(loc='best', fontsize=15)
            plt.xticks(fontsize=20)
            plt.yticks(fontsize=20)
            plt.xlabel(r'$\beta$', fontsize=25)
            plt.ylabel(r'$HR$', fontsize=25)
            plt.ylim(-0.1, 1)
            # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.savefig('C:/Users/94353/Desktop/CTN/CN.eps', format='eps')
        plt.show()
    def compare_corr_weighted(self, networks):
        X = [x / 100 for x in range(1, 11)]
        fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(20,20))
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork_weighted(networks[i][0])
            nodes = sorted(TG[0].nodes)

            tempGCNL = []
            GCNL = self.methods.GCN_LSTM_weighted(TG, networks[i][1], networks[i][2], 0.05, networks[i][3])

            tempNode2v = []
            node2v = self.methods.embedding_LSTM(TG, networks[i][1], networks[i][2], 0.05, networks[i][3], 'node2vec')

            tempS2v = []
            S2v = self.methods.embedding_LSTM(TG, networks[i][1], networks[i][2], 0.05, networks[i][3], 'struc2vec')

            tempTDC = []
            TDC = self.methods.TemporalDC(TG, 0.05, 1)

            tempKshell = []
            TK = self.methods.TemporalKshell(TG)
            for j in X:
                print(j)
                label = np.load('Weighted/Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(j) + '.npy')
                tempGCNL.append(self.corr(nodes, label, GCNL))
                tempTDC.append(self.corr(nodes, label, TDC))
                tempKshell.append(self.corr(nodes, label, TK))
                tempNode2v.append(self.corr(nodes, label, node2v))
                tempS2v.append(self.corr(nodes, label, S2v))

            plt.subplot(2, 2, i + 1)
            plt.plot(X, tempGCNL, 'r', label='DGCNs', marker='o')
            plt.plot(X, tempTDC, 'g', label='TDC', marker='*')
            plt.plot(X, tempKshell, 'b', label='TK', marker='v')
            plt.plot(X, tempNode2v, 'k', label='N2V-LSTM', marker='^')
            plt.plot(X, tempS2v, 'g', label='S2V-LSTM', marker='>')
            if i == 0:
                plt.legend(loc='best', fontsize=15)
            plt.xticks(fontsize=20)
            plt.yticks(fontsize=20)
            plt.xlabel(r'$\beta$', fontsize=25)
            plt.ylabel(r'$\tau$', fontsize=25)
            plt.ylim(-1, 1)
            # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.savefig('C:/Users/94353/Desktop/CTN/corr.eps', format='eps')
        plt.show()

    def compare_topK(self, K):
        networks = [['Email', 39, 29]]
        X = [x / 100 for x in range(1, 11)]
        fig, ax = plt.subplots(nrows=3, ncols=3)
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork(networks[i][0])[networks[i][1]-10:networks[i][1]]
            nodes = sorted(TG[0].nodes)
            tempGCNL = []
            GCNL = self.methods.GCN_LSTM_weighted(TG, networks[i][1], networks[i][2], 0.05)

            tempTDC = []
            TDC = self.methods.TemporalDC(TG, 0.05, 1)

            tempKshell = []
            TK = self.methods.TemporalKshell(TG)
            for j in X:
                print(j)
                label = np.load('Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(j) + '.npy')
                tempGCNL.append(self.topK(nodes, label, GCNL, K))
                tempTDC.append(self.topK(nodes, label, TDC, K))
                tempKshell.append(self.topK(nodes, label, TK, K))

            plt.subplot(3, 3, i + 1)
            plt.plot(X, tempGCNL, 'r', label='GCNL', marker='o')
            plt.plot(X, tempTDC, 'g', label='TDC', marker='*')
            plt.plot(X, tempKshell, 'b', label='TK', marker='v')
            if i == 0:
                plt.legend(loc='best', fontsize=15)
            plt.xticks(fontsize=20)
            plt.yticks(fontsize=20)
            plt.xlabel(r'$\beta$', fontsize=25)
            plt.ylabel(r'CN', fontsize=25)
            plt.ylim(0, 1)
            # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.show()
    def compare_corr(self):
        networks = [['Email', 39, 29]]
        X = [x / 100 for x in range(1, 11)]
        fig, ax = plt.subplots(nrows=3, ncols=3)
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork(networks[i][0])[networks[i][1]-10:networks[i][1]]
            nodes = sorted(TG[0].nodes)

            tempGCNL = []
            GCNL = self.methods.GCN_LSTM_weighted(TG, networks[i][1], networks[i][2], 0.05)

            tempNode2v = []
            node2v = self.methods.GCN_LSTM(TG, networks[i][1], networks[i][2], 0.05)

            tempTDC = []
            TDC = self.methods.TemporalDC(TG, 0.05, 1)

            tempKshell = []
            TK = self.methods.TemporalKshell(TG)
            for j in X:
                print(j)
                label = np.load('Label/' + TG[0].name + '_' + str(networks[i][1]) + '_' + str(j) + '.npy')
                tempGCNL.append(self.corr(nodes, label, GCNL))
                tempTDC.append(self.corr(nodes, label, TDC))
                tempKshell.append(self.corr(nodes, label, TK))

            plt.subplot(3, 3, i + 1)
            plt.plot(X, tempGCNL, 'r', label='GCNL', marker='o')
            plt.plot(X, tempTDC, 'g', label='TDC', marker='*')
            plt.plot(X, tempKshell, 'b', label='TK', marker='v')
            if i == 0:
                plt.legend(loc='best', fontsize=15)
            plt.xticks(fontsize=20)
            plt.yticks(fontsize=20)
            plt.xlabel(r'$\beta$', fontsize=25)
            plt.ylabel('corr', fontsize=25)
            plt.ylim(0, 1)
            # plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.show()
    def compare_time(self, networks):
        X = [x / 100 for x in range(1, 11)]
        fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(20,20))
        for i in range(len(networks)):
            print(networks[i])
            gn_networks = GN.Networks()
            TG = gn_networks.RealNetwork_weighted(networks[i][0])
            nodes = sorted(TG[0].nodes)
            tt= time.time()
            tempGCNL = []
            GCNL = self.methods.GCN_LSTM_weighted(TG, networks[i][1], networks[i][2], 0.05, networks[i][3])
            print('DGCNS:', time.time()-tt)

            tt = time.time()
            tempNode2v = []
            node2v = self.methods.embedding_LSTM(TG, networks[i][1], networks[i][2], 0.05, networks[i][3], 'node2vec')
            print('node2v:', time.time() - tt)

            tt = time.time()
            tempS2v = []
            S2v = self.methods.embedding_LSTM(TG, networks[i][1], networks[i][2], 0.05, networks[i][3], 'struc2vec')
            print('S2v:', time.time() - tt)

            tt = time.time()
            tempTDC = []
            TDC = self.methods.TemporalDC(TG[:networks[i][1]], 0.05, 1)
            print('TDC:', time.time() - tt)

            tt = time.time()
            tempKshell = []
            TK = self.methods.TemporalKshell(TG[:networks[i][1]])
            print('TK:', time.time() - tt)