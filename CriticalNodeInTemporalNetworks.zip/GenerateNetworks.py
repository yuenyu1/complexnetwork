#coding=utf-8

import numpy as np
import networkx as nx
import random
import datetime

'''
真实社交网络的四种基本模式：
（1）递增：与外界交互越来越频繁（粉丝越来越多）
（2）递减：与外界交互越来越少（粉丝越来越少）
（3）平稳：与外界交互相对平稳（粉丝数量基本不变）
（4）随机：与外界交互时时多时少（粉丝数量随机变化）
探索真实社交网络的共性，生成模拟网络用作训练集
节点分为x类：???
0：倾向：与现有联系人保持联系几率大，与陌生人联系几率大
1：倾向：与现有联系人保持联系几率小，与陌生人联系几率小
2：倾向：与现有联系人保持联系几率大，与陌生人联系几率小
'''
class Networks:
    def __init__(self):
        ...
    def generateSnapshotTemporalNetworks(self, N, M, alpha, d):
        '''
        生成Snapshot模式的时序网络
        :param N: 节点数
        :param M: 边数/节点数
        :param alpha: 每个snapshot的变化程度
        :param d: 存储目录
        :return: None
        '''
        #生成N个snapshots，每次重新连接alpha比例的边
        subd = '_'.join([str(x) for x in [N, M, alpha]])
        tempNet = nx.barabasi_albert_graph(N, M)
        diff = int(tempNet.number_of_edges()*alpha)
        nx.write_adjlist(tempNet, 'networks/'+d+'/'+subd+'/'+'0')
        for i in range(1, 100):
            edgeList = list(tempNet.edges())
            random.shuffle(edgeList)
            tempNet.remove_edges_from(edgeList[:diff])
            for j in range(diff):
                while True:
                    nodeList = random.choices(list(tempNet.nodes()), k=2)
                    if nodeList[0] != nodeList[1] and not tempNet.has_edge(nodeList[0], nodeList[1]):
                        tempNet.add_edge(nodeList[0], nodeList[1])
                        break
            nx.write_adjlist(tempNet, 'networks/'+d+'/'+subd+'/'+ str(i))

    def RealNetwork(self, network):
        '''
        载入真实时序网络
        :param fileName:文件名
        :return: 真实时序网络
        '''
        fileName, d, l, r, is_directed = network

        G = nx.DiGraph()
        if not is_directed:
            G.to_undirected()
        t = []
        for line in open('networks/'+fileName, 'r').readlines():
            t.append(float(line.strip().replace(' ', '\t').split('\t')[-1]))
        begin = datetime.datetime.fromtimestamp(min(t))
        # interval = int((max(t)-min(t))/99)
        # edges = dict((k,[]) for k in range(100))
        interval = 86400*d
        L = int((max(t) - min(t)) / interval + 1)
        edges = dict((k, []) for k in range(L))
        for line in open('networks/'+fileName, 'r').readlines():
            contents = line.strip().replace(' ', '\t').split('\t')
            if contents[0] != contents[1]:
                G.add_nodes_from([contents[0], contents[1]])
                edges[int((datetime.datetime.fromtimestamp(float(contents[-1]))-begin).total_seconds()/interval)].append((contents[0], contents[1]))
        TG = []
        for i in range(L):
            g = G.copy()
            g.add_edges_from(edges[i])
            g.name = fileName
            TG.append(g)
        return TG[l:r]

    def RealNetwork_weighted(self, network):
        '''
        载入真实时序网络
        :param fileName:文件名
        :return: 真实时序网络
        '''
        fileName, d, l, r, is_directed, threshold = network

        G = nx.DiGraph()
        if not is_directed:
            G.to_undirected()
        t = []
        for line in open('networks/' + fileName, 'r').readlines():
            t.append(float(line.strip().replace(' ', '\t').split('\t')[-1]))
        begin = datetime.datetime.fromtimestamp(min(t))
        # interval = int((max(t)-min(t))/99)
        # edges = dict((k,[]) for k in range(100))
        interval = 86400 * d
        L = int((max(t) - min(t)) / interval + 1)
        edges = dict((k, []) for k in range(L))
        for line in open('networks/' + fileName, 'r').readlines():
            contents = line.strip().replace(' ', '\t').split('\t')
            if contents[0] != contents[1]:
                G.add_nodes_from([contents[0], contents[1]])
                edges[int(
                    (datetime.datetime.fromtimestamp(float(contents[-1])) - begin).total_seconds() / interval)].append(
                    (contents[0], contents[1]))
        TG = []
        for i in range(L):
            if len(edges[i]) < threshold:
                continue
            g = G.copy()
            for e in edges[i]:
                if g.has_edge(e[0], e[1]):
                    g[e[0]][e[1]]['weight'] += 1
                else:
                    g.add_edge(e[0], e[1], weight=1)
            g.name = fileName
            TG.append(g)
        return TG[l:r]

    def TSFNetworks(self, name, N, M, alpha, d):
        '''
        载入模拟时序网络
        :param name: 网络名称
        :param N:节点数
        :param M:边数
        :param alpha:变化程度
        :param d:目录
        :return: 网络
        '''
        subd = '_'.join([str(x) for x in [N, M, alpha]])
        TSF = []
        for i in range(100):
            BA = nx.read_adjlist('networks/'+d+'/' +subd+'/'+ str(i))
            BA.name = name +'_'+ subd
            TSF.append(BA)
        return TSF
# N = Networks()
# # Email = N.RealNetwork(['Email', 7, 0, 75])
# # print(len(Email))
# # for g in Email:
# #     print(g.number_of_nodes(), g.number_of_edges())

# N = Networks()
# Email = N.RealNetwork(['Email', 7, 0, 75])
# print(len(Email))
# for g in Email:
#     print(g.number_of_nodes(), g.number_of_edges())


# CM = RealNetwork('UCI')#28
# INF = RealNetwork('infectious')
# BTC_alpha = RealNetwork('bitcoinalpha')
# BTC_otc = RealNetwork('bitcoinotc')
# for g in BTC_otc:
#     print(g.number_of_nodes(), g.number_of_edges())


# TSF = TSFNetworks('Train', 1000, 4, 0.02, 'BAtrain')
# nodes = sorted(TSF[0].nodes())
# for node in nodes:
#     print(node, )