#coding=utf-8
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.autograd import Variable
import numpy as np

class Dataset(Dataset):
    def __init__(self, name, tempT, beta, T):

        self.data = np.load('Feature/'+name+'_'+str(tempT)+'_'+str(T)+'.npy')
        self.label = np.load('Label/'+name+'_'+str(tempT)+'_'+str(beta)+'.npy')

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        data = self.data[idx]
        label = self.label[idx]
        """Convert ndarrays to Tensors."""
        return torch.from_numpy(data).float(), torch.from_numpy(label).float()

class Dataset_weighted(Dataset):
    def __init__(self, name, tempT, beta, T):

        self.data = np.load('Weighted/Feature/'+name+'_'+str(tempT)+'_'+str(T)+'.npy')
        self.label = np.load('Weighted/Label/'+name+'_'+str(tempT)+'_'+str(beta)+'.npy')

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        data = self.data[idx]
        label = self.label[idx]
        """Convert ndarrays to Tensors."""
        return torch.from_numpy(data).float(), torch.from_numpy(label).float()

class Dataset_embedding(Dataset):
    def __init__(self, name, tempT, beta, T, method):

        self.data = np.load(method+'/Feature/'+name+'_'+str(tempT)+'_'+str(T)+'.npy')
        self.label = np.load('Weighted/Label/'+name+'_'+str(tempT)+'_'+str(beta)+'.npy')

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        data = self.data[idx]
        label = self.label[idx]
        """Convert ndarrays to Tensors."""
        return torch.from_numpy(data).float(), torch.from_numpy(label).float()

class CNN(nn.Module):
    def __init__(self, k):
        super(CNN, self).__init__()
        self.conv1 = nn.Sequential(  # input shape (1,28,28)
            nn.Conv2d(in_channels=1,  # input height
                      out_channels=16,  # n_filter
                      kernel_size=5,  # filter size
                      stride=1,  # filter step
                      padding=2  # con2d出来的图片大小不变
                      ),  # output shape (16,28,28)
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2)  # 2x2采样，output shape (16,14,14)

        )
        self.conv2 = nn.Sequential(nn.Conv2d(16, 32, 5, 1, 2),  # output shape (32,7,7)
                                   nn.ReLU(),
                                   nn.MaxPool2d(2))
        self.out = nn.Linear(int(32 * k/4 * k/4), 1)

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = x.view(x.size(0), -1)  # flat (batch_size, 32*7*7)
        output = self.out(x)
        return output

class LSTM(nn.Module):
    def __init__(self):
        super(LSTM,self).__init__()

        self.lstm = nn.LSTM(
            input_size=1,
            hidden_size=64,
            num_layers=2,
            batch_first=True,  #（time_step,batch,input）时是Ture
        )
        self.out = nn.Linear(64,1)

    def forward(self, x):
        r_out,(h_n,h_c) = self.lstm(x,None)  # x (batch,time_step,input_size)
        out = self.out(r_out[:,-1,:]) #(batch,time_step,input)
        return out
class CNN_LSTM(nn.Module):
    def __init__(self, T):
        self.T = T
        super(CNN_LSTM, self).__init__()
        self.conv1 = nn.Sequential(  # input shape (1,28,28)
            nn.Conv2d(in_channels=1,  # input height
                      out_channels=16,  # n_filter
                      kernel_size=5,  # filter size
                      stride=1,  # filter step
                      padding=2  # con2d出来的图片大小不变
                      ),  # output shape (16,28,28)
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2)  # 2x2采样，output shape (16,14,14)

        )
        self.conv2 = nn.Sequential(nn.Conv2d(16, 32, 5, 1, 2),  # output shape (32,7,7)
                                   nn.ReLU(),
                                   nn.MaxPool2d(2))
        self.out_cnn = nn.Linear(int(32 * 7 * 7), 1)


        self.lstm = nn.LSTM(
            input_size=1,
            hidden_size=64,
            num_layers=2,
            batch_first=True,  # （time_step,batch,input）时是Ture
        )
        self.out_lstm = nn.Linear(64, 1)
    def forward(self, x):
        num = x.size(0)
        x = x.view([x.size(0)*x.size(1), 1, 28, 28])
        x = self.conv1(x)
        x = self.conv2(x)
        x = x.view(x.size(0), -1)
        x = self.out_cnn(x)
        x = x.view([num, self.T, 1])
        r_out, (h_n, h_c) = self.lstm(x, None)  # x (batch,time_step,input_size)
        out = self.out_lstm(r_out[:, -1, :])  # (batch,time_step,input)
        return out


class CNN_LSTM2(nn.Module):
    def __init__(self, T):
        self.T = T
        super(CNN_LSTM2, self).__init__()
        self.CONVs = [[] for i in range(T)]
        for i in range(T):

            self.CONVs[i].append(nn.Sequential(  # input shape (1,28,28)
                nn.Conv2d(in_channels=1,  # input height
                          out_channels=16,  # n_filter
                          kernel_size=5,  # filter size
                          stride=1,  # filter step
                          padding=2  # con2d出来的图片大小不变
                          ),  # output shape (16,28,28)
                nn.ReLU(),
                nn.MaxPool2d(kernel_size=2)  # 2x2采样，output shape (16,14,14)

            ).to('cuda'))
            self.CONVs[i].append(nn.Sequential(nn.Conv2d(16, 32, 5, 1, 2),  # output shape (32,7,7)
                                       nn.ReLU(),
                                       nn.MaxPool2d(2)).to('cuda'))
            self.CONVs[i].append(nn.Linear(int(32 * 7 * 7), 1).to('cuda'))

        self.lstm = nn.LSTM(
            input_size=1,
            hidden_size=64,
            num_layers=2,
            batch_first=True,  # （time_step,batch,input）时是Ture
        ).to('cuda')
        self.out_lstm = nn.Linear(64, 1).to('cuda')

    def forward(self, x):
        tempZ = []
        for i in range(self.T):
            z = x[:, i]
            z = self.CONVs[i][0](z)
            z = self.CONVs[i][1](z)
            z = z.view(z.size(0), -1)
            z = self.CONVs[i][2](z)
            tempZ.append(z)
        x = torch.cat(tempZ, dim=1).view([x.size(0), self.T, 1])
        r_out, (h_n, h_c) = self.lstm(x, None)  # x (batch,time_step,input_size)
        out = self.out_lstm(r_out[:, -1, :])  # (batch,time_step,input)
        return out

class Train:
    def __init__(self):
        ...

    def train_CNN(self,TrainName, k, beta, ):
        train_dataset = Dataset(TrainName, k, 0.05)
        data = DataLoader(train_dataset, batch_size=Train[0].number_of_nodes(), shuffle=True)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        cnn = CNN(k).to(device)
        # optimizer
        optimizer = torch.optim.Adam(cnn.parameters(), lr=0.001)
        # loss_fun
        loss_func = nn.MSELoss()
        # training loop
        for epoch in range(500):
            for i, (x, y) in enumerate(data):
                batch_x = Variable(x).to(device)
                batch_y = Variable(y).to(device)
                # 输入训练数据
                output = cnn(batch_x)
                # 计算误差
                loss = loss_func(output, batch_y)
                print(epoch + 1, i + 1, loss.item())
                # 清空上一次梯度
                optimizer.zero_grad()
                # 误差反向传递
                loss.backward()
                # 优化器参数更新
                optimizer.step()
                state = {'net': cnn.state_dict(),
                         'optimizer': optimizer.state_dict(),
                         'epoch': epoch + 1}
                torch.save(state, 'GCN/' + TrainName + '_' + str(k) + '_' + str(beta) + '.pth')

    def train_LSTM(self,TrainName, tempT, beta, T, method):
        train_dataset = Dataset_embedding(TrainName, tempT, 0.05, T, method)
        data = DataLoader(train_dataset, batch_size=50, shuffle=True)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        lstm = LSTM().to(device)
        # optimizer
        optimizer = torch.optim.Adam(lstm.parameters(), lr=0.001)
        # loss_fun
        loss_func = nn.MSELoss()
        # training loop
        for epoch in range(300):
            for i, (x, y) in enumerate(data):
                batch_x = Variable(x).to(device)
                batch_y = Variable(y).to(device)
                # 输入训练数据
                output = lstm(batch_x)
                # 计算误差
                loss = loss_func(output, batch_y)
                print(epoch + 1, i + 1, loss.item())
                # 清空上一次梯度
                optimizer.zero_grad()
                # 误差反向传递
                loss.backward()
                # 优化器参数更新
                optimizer.step()
                state = {'net': lstm.state_dict(),
                         'optimizer': optimizer.state_dict(),
                         'epoch': epoch + 1}
                torch.save(state, method+'/'+'LSTM/' + TrainName + '_' + str(tempT)+ '_' + str(beta) +'_' + str(T) + '.pth')
    def train_CNN_LSTM(self,TrainName, tempT, beta, T):
        train_dataset = Dataset(TrainName, tempT, beta, T)
        data = DataLoader(train_dataset, batch_size=50, shuffle=True)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        cnn_lstm = CNN_LSTM(T).to(device)
        # optimizer
        optimizer = torch.optim.Adam(cnn_lstm.parameters(), lr=0.001)
        # loss_fun
        loss_func = nn.MSELoss()
        # training loop
        for epoch in range(300):
            for i, (x, y) in enumerate(data):
                batch_x = Variable(x).to(device)
                batch_y = Variable(y).to(device)
                # 输入训练数据
                output = cnn_lstm(batch_x)
                # 计算误差
                loss = loss_func(output, batch_y)
                print(epoch + 1, i + 1, loss.item())
                # 清空上一次梯度
                optimizer.zero_grad()
                # 误差反向传递
                loss.backward()
                # 优化器参数更新
                optimizer.step()
                state = {'net': cnn_lstm.state_dict(),
                         'optimizer': optimizer.state_dict(),
                         'epoch': epoch + 1}
                torch.save(state, 'CNN_LSTM/' + TrainName + '_' + str(tempT)+ '_' + str(beta) +'_' + str(T) + '.pth')
    def train_CNN_LSTM2(self,TrainName, tempT, beta, T):
        train_dataset = Dataset(TrainName, tempT, beta, T)
        data = DataLoader(train_dataset, batch_size=50, shuffle=True)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        cnn_lstm = CNN_LSTM2(T).to(device)
        # optimizer
        optimizer = torch.optim.Adam(cnn_lstm.parameters(), lr=0.001)
        # loss_fun
        loss_func = nn.MSELoss()
        # training loop
        for epoch in range(300):
            for i, (x, y) in enumerate(data):
                batch_x = Variable(x).to(device)
                batch_y = Variable(y).to(device)
                # 输入训练数据
                output = cnn_lstm(batch_x)
                # 计算误差
                loss = loss_func(output, batch_y)
                print(epoch + 1, i + 1, loss.item())
                # 清空上一次梯度
                optimizer.zero_grad()
                # 误差反向传递
                loss.backward()
                # 优化器参数更新
                optimizer.step()
                state = {'net': cnn_lstm.state_dict(),
                         'optimizer': optimizer.state_dict(),
                         'epoch': epoch + 1}
                torch.save(state, 'CNN_LSTM2/' + TrainName + '_' + str(tempT)+ '_' + str(beta) +'_' + str(T) + '.pth')

    def train_CNN_LSTM_weighted(self,TrainName, tempT, beta, T):
        train_dataset = Dataset_weighted(TrainName, tempT, beta, T)
        data = DataLoader(train_dataset, batch_size=50, shuffle=True)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        cnn_lstm = CNN_LSTM(T).to(device)
        # optimizer
        optimizer = torch.optim.Adam(cnn_lstm.parameters(), lr=0.001)
        # loss_fun
        loss_func = nn.MSELoss()
        # training loop
        for epoch in range(300):
            for i, (x, y) in enumerate(data):
                batch_x = Variable(x).to(device)
                batch_y = Variable(y).to(device)
                # 输入训练数据
                output = cnn_lstm(batch_x)
                # 计算误差
                loss = loss_func(output, batch_y)
                print(epoch + 1, i + 1, loss.item())
                # 清空上一次梯度
                optimizer.zero_grad()
                # 误差反向传递
                loss.backward()
                # 优化器参数更新
                optimizer.step()
                state = {'net': cnn_lstm.state_dict(),
                         'optimizer': optimizer.state_dict(),
                         'epoch': epoch + 1}
                torch.save(state, 'Weighted/CNN_LSTM/' + TrainName + '_' + str(tempT)+ '_' + str(beta) +'_' + str(T) + '.pth')
    def train_CNN_LSTM2_weighted(self,TrainName, tempT, beta, T):
        train_dataset = Dataset_weighted(TrainName, tempT, beta, T)
        data = DataLoader(train_dataset, batch_size=50, shuffle=True)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        cnn_lstm = CNN_LSTM2(T).to(device)
        # optimizer
        optimizer = torch.optim.Adam(cnn_lstm.parameters(), lr=0.001)
        # loss_fun
        loss_func = nn.MSELoss()
        # training loop
        for epoch in range(300):
            for i, (x, y) in enumerate(data):
                batch_x = Variable(x).to(device)
                batch_y = Variable(y).to(device)
                # 输入训练数据
                output = cnn_lstm(batch_x)
                # 计算误差
                loss = loss_func(output, batch_y)
                print(epoch + 1, i + 1, loss.item())
                # 清空上一次梯度
                optimizer.zero_grad()
                # 误差反向传递
                loss.backward()
                # 优化器参数更新
                optimizer.step()
                state = {'net': cnn_lstm.state_dict(),
                         'optimizer': optimizer.state_dict(),
                         'epoch': epoch + 1}
                torch.save(state, 'Weighted/CNN_LSTM2/' + TrainName + '_' + str(tempT)+ '_' + str(beta) +'_' + str(T) + '.pth')
class Predict:
    def __init__(self):
        ...

    def predict_CNN(self, feature, TrainName):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        cnn = CNN(28).to(device)
        checkpoint = torch.load('GCN/' + TrainName + '.pth')
        cnn.load_state_dict(checkpoint['net'])
        data = torch.from_numpy(feature).float()
        data = data.to(device)
        outputs = cnn(data)
        re = []
        for output in outputs:
            re.append([output.item()])
        return re

    def predict_LSTM(self, nodes, feature, TrainName):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        lstm = LSTM().to(device)
        checkpoint = torch.load(TrainName)
        lstm.load_state_dict(checkpoint['net'])
        data = torch.from_numpy(feature).float()
        data = data.to(device)
        outputs = lstm(data)
        re = []
        for i in range(len(nodes)):
            re.append((nodes[i], outputs[i].item()))
        rank = [x[0] for x in sorted(re, key=lambda x: (x[1],x[0]), reverse=True)]
        return rank
    def predict_CNN_LSTM(self, nodes, feature, TrainName, T):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        lstm = CNN_LSTM(T).to(device)
        checkpoint = torch.load(TrainName)
        lstm.load_state_dict(checkpoint['net'])
        re = []
        left = 0
        right = 100
        while left < len(feature):
            if right > len(feature):
                right = len(feature)
            tempData = torch.from_numpy(feature[left:right]).float()
            tempData = tempData.to(device)
            outputs = lstm(tempData)
            for i in range(left, right):
                re.append((nodes[i], outputs[i-left].item()))
            left += 100
            right += 100
        rank = [x[0] for x in sorted(re, key=lambda x: (x[1],x[0]), reverse=True)]
        return rank
    def predict_CNN_LSTM_weighted(self, nodes, feature, TrainName, T):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        lstm = CNN_LSTM(T).to(device)
        checkpoint = torch.load(TrainName)
        lstm.load_state_dict(checkpoint['net'])
        re = []
        left = 0
        right = 100
        while left < len(feature):
            if right > len(feature):
                right = len(feature)
            tempData = torch.from_numpy(feature[left:right]).float()
            tempData = tempData.to(device)
            outputs = lstm(tempData)
            for i in range(left, right):
                re.append((nodes[i], outputs[i-left].item()))
            left += 100
            right += 100
        rank = [x[0] for x in sorted(re, key=lambda x: (x[1],x[0]), reverse=True)]
        return rank

    def predict_CNN_LSTM2_weighted(self, nodes, feature, TrainName, T):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        lstm = CNN_LSTM2(T).to(device)
        checkpoint = torch.load(TrainName)
        lstm.load_state_dict(checkpoint['net'])
        re = []
        left = 0
        right = 100
        while left < len(feature):
            if right > len(feature):
                right = len(feature)
            tempData = torch.from_numpy(feature[left:right]).float()
            tempData = tempData.to(device)
            outputs = lstm(tempData)
            for i in range(left, right):
                re.append((nodes[i], outputs[i-left].item()))
            left += 100
            right += 100
        rank = [x[0] for x in sorted(re, key=lambda x: (x[1],x[0]), reverse=True)]
        return rank