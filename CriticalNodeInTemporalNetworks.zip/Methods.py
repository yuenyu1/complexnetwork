#coding=utf-8

import networkx as nx
import DL_model as DL
import numpy as np

class Methods:
    def __init__(self):
        ...
    def GCN_LSTM(self, temporalG, tempT, trainT, beta, T):
        dl_predict = DL.Predict()
        nodes = sorted(temporalG[0].nodes())
        return dl_predict.predict_CNN_LSTM(nodes, np.load('Feature/' + temporalG[0].name + '_' + str(tempT) +'_' + str(T) + '.npy'),
                                           'CNN_LSTM/' + temporalG[0].name + '_' + str(trainT)+ '_' + str(beta) + '_' + str(T) +'.pth', T)

    def GCN_LSTM_weighted(self, temporalG, tempT, trainT, beta, T):
        dl_predict = DL.Predict()
        nodes = sorted(temporalG[0].nodes())
        return dl_predict.predict_CNN_LSTM_weighted(nodes, np.load('Weighted/Feature/' + temporalG[0].name + '_' + str(tempT) +'_' + str(T) + '.npy'),
                                           'Weighted/CNN_LSTM/' + temporalG[0].name + '_' + str(trainT)+ '_' + str(beta) + '_' + str(T) +'.pth', T)

    def GCN_LSTM2_weighted(self, temporalG, tempT, trainT, beta, T):
        dl_predict = DL.Predict()
        nodes = sorted(temporalG[0].nodes())
        return dl_predict.predict_CNN_LSTM2_weighted(nodes, np.load('Weighted/Feature/' + temporalG[0].name + '_' + str(tempT) +'_' + str(T) + '.npy'),
                                           'Weighted/CNN_LSTM2/' + temporalG[0].name + '_' + str(trainT)+ '_' + str(beta) + '_' + str(T) +'.pth', T)

    def embedding_LSTM(self, temporalG, tempT, trainT, beta, T, method):
        dl_predict = DL.Predict()
        nodes = sorted(temporalG[0].nodes())
        return dl_predict.predict_LSTM(nodes, np.load(method+'/Feature/' + temporalG[0].name + '_' + str(tempT) +'_' + str(T) + '.npy'),
                                           method+'/LSTM/' + temporalG[0].name + '_' + str(trainT)+ '_' + str(beta) + '_' + str(T) +'.pth')

    def TemporalDC(self, temporalG, beta, miu):
        L = len(temporalG)
        nodeSocre = dict((k, 0) for k in temporalG[0].nodes())
        N = len(nodeSocre)
        S = 0
        V = np.ones((N,1))
        for t in range(L):
            H = 1
            for alpha in range(t)[::-1]:
                tempA = nx.adjacency_matrix(temporalG[alpha], nodelist=[x for x in temporalG[0].nodes()]).todense()
                H = H*(beta*tempA+(1-miu)*np.eye(N))
            A= nx.adjacency_matrix(temporalG[t], nodelist=[x for x in temporalG[0].nodes()]).todense()
            S += beta*H*A*V
        for i in range(len(temporalG[0].nodes())):
            nodeSocre[list(temporalG[0].nodes())[i]] = S[i, 0]

        return [x[0] for x in sorted(nodeSocre.items(), key=lambda x: x[1], reverse=True)]

    def TemporalKshell(self, temporalG):  # 时序Kshell
        W = {}
        tk = dict((k, 0) for k in temporalG[0].nodes())
        for G in temporalG:
            G.remove_edges_from(nx.selfloop_edges(G))
            tempKshell = nx.core_number(G)
            for edge in G.edges():
                w = min(tempKshell[edge[0]], tempKshell[edge[1]])
                if edge in W.keys():
                    W[edge] += w
                else:
                    W[edge] = w
        for edge in W.keys():
            tk[edge[0]] += W[edge]
            tk[edge[1]] += W[edge]
        return [x[0] for x in sorted(tk.items(), key=lambda x: x[1], reverse=True)]